# NFT_Portfolio_Tracker

A Native android app that shows all the NFT collections of users in their fingertips.

An App where user can enter their address or others and get all the NFTs held by the address. All the NFTs found in their wallet address could be seen with the image, contract and creator address which is powered by the swift NFT Port's API. This is the very basic proto of what we thought to build. 

We will be continuing this project and using NFT Port's API to build an interactive portfolio tracker with useful stats for them like charts of their mints and collection with current floor price of those NFTs. 

We will also be building a portfolio battle with other wallets which compares stuff with some important metrics and show the portfolio in a gamified manner. 

APK Link: https://drive.google.com/file/d/1V-HIGW1V9DPlfAdoZhnX5yshW5RK5fo4/view?usp=sharing
